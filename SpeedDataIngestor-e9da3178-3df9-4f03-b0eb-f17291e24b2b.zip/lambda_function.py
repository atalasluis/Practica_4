import json
import boto3
import time
from datetime import datetime
import logging

logger = logging.getLogger()
logger.setLevel(logging.INFO)
dynamodb = boto3.resource('dynamodb')

# Nombre exacto de tu tabla
table = dynamodb.Table('speed_events')

def lambda_handler(event, context):
    try:
        # Extrae el ID inyectado por la Regla IoT
        device_id = event.get('device_id', 'unknown-device')
        
        # Mapea las variables del payload del ESP32
        current_speed = event.get('currentSpeed', 0)
        speed_limit = event.get('speedLimit', 0)
        
        timestamp_epoch = int(time.time())
        dt = datetime.fromtimestamp(timestamp_epoch)
        
        item = {
            'device_id': device_id,          # Partition Key
            'timestamp': timestamp_epoch,    # Sort Key
            'speed': int(current_speed),
            'exceeded': current_speed > speed_limit,
            'speedLimit': int(speed_limit),
            'alarmActivated': event.get('alarm', False),
            'hour': dt.hour,
            'day': dt.strftime('%A')
        }
        
        table.put_item(Item=item)
        logger.info(f"Evento guardado exitosamente para {device_id}")
        
        return {"statusCode": 200, "body": "Success"}
        
    except Exception as e:
        logger.error(f"Error procesando evento: {e}", exc_info=True)
        return {"statusCode": 500, "body": "Error interno"}